/**
 *
 * @author Rodrigo
 */
package com.mycompany.coches;


// Importa de la biblioteca/librería el paquete "Connection".
import java.sql.Connection;
// Importa de la biblioteca/librería el paquete "DriverManager".
import java.sql.DriverManager;
// Importa de la biblioteca/librería el paquete "ResultSet".
import java.sql.ResultSet;
// Importa de la biblioteca/librería el paquete "SQLException".
import java.sql.SQLException;
// Importa de la biblioteca/librería el paquete "Statement".
import java.sql.Statement;

public class PruebaAccesoDatos{
    // Configuración para MySQL en Docker.
    private static final String URL = "jdbc:mysql://localhost:3306";
    private static final String USER = "root";
    private static final String PASSWORD = "root";
    private static final String DB_NAME = "GestorCoches";

    // Crea el método principal del programa.
    public static void main(String[] args){
        // Crea un objeto para llamar a los métodos de "AccesoDatos".
        AccesoDatos AD = new AccesoDatos();
        
        // Llama a los distyintos métodos de "AccesoDatos".
        AD.crearBaseDeDatos();
        AD.abrirConexion();
        AD.crearTablas();
        AD.mostrarDatosCoches();
        AD.modificarCoche("BA-3333", 5000);
        AD.borrarCoche("MA-1111");
        AD.insertarCoche("AA-0005", "Ford", 4500, "1A");
        AD.insertarPropietario("X25", "Jose", 54);
        AD.mostrarPropietarioYCoches("1A");
        AD.borrarPropietario("1C");
        AD.cerrarConexion();
        try (Connection cn = DriverManager.getConnection(URL, USER, PASSWORD, DB_NAME); Statement st = cn.createStatement()){
            System.out.println("\n\n\t\tConectado a la base de datos.");
            
            // Crea una base de datos si no existe.
            String sql = "CREATE DATABASE IF NOT EXISTS " + DB_NAME + ";";
            st.execute(sql);
            System.out.println("\n\n\t\tBase de datos, '" + DB_NAME + "', creada exitosamente.");
            
            // Seleciona la base de datos creada.
            st.execute("USE " + DB_NAME);
            
            // Crea la tabla "Propietarios".
            sql = "CREATE TABLE IF NOT EXISTS Propietarios (" +
                    "DNI VARCHAR(10)," +
                    "Nombre VARCHAR(40)," +
                    "Edad INTEGER," +
                    "UNIQUE KEY(DNI)" +
               ")";
            st.execute(sql);
            System.out.println("\n\n\t\tTabla 'Propietarios' creada exitosamente.");

            sql = "CREATE TABLE IF NOT EXISTS Coches (" +
                    "Matricula VARCHAR(10)," +
                    "Marca VARCHAR(20)," +
                    "Precio INTEGER," +
                    "DNI VARCHAR (10)," +
                    "UNIQUE KEY(Matricula)," +
                    "FOREIGN KEY (DNI) References Propietarios(DNI)" +
                ")";
            st.execute(sql);
            System.out.println("\n\t\tTabla 'Coches' creada exitosamente.\n\n");
            
            System.out.println("\n\n\t\tTabla verificadas y creadas correctamente.");
            
            // Inserta nuevos datos en la tabla creada.
                // Declara una variable que tendrá la función de contabilizar el número de filas.
            int rowsAffected = 0;
            
            sql = "INSERT INTO Propietarios (DNI, Nombre, Edad) VALUES" +
                      "('1A', 'Pepe', '30')," +
                      "('1B','Ana', '40')," +
                      "('1C','Maria', '50')";
            rowsAffected = st.executeUpdate(sql);
            System.out.println("\n\n\tSe han insertado un total de " + rowsAffected + " filas en la tabla \"Propietarios\".");
            
            sql = "INSERT INTO Coches (Matricula, Marca, Precio, DNI) VALUES" +
                      "('MA-1111','Opel',1000,'1A')," +
                      "('MA-2222','Renault',2000,'1A')," +
                      "('BA-3333', 'Seat', 3000,'1B')";
            rowsAffected = st.executeUpdate(sql);
            System.out.println("\n\tSe han insertado un total de " + rowsAffected + " filas en la tabla \"Coches\".");
            
            System.out.println("\n\n\n\t<==========Combrobación rápida de las tablas ==========>\n");

            ResultSet rs;

            // Selecciona datos de la tabla "propietarios".
            sql = "SELECT * FROM Propietarios";
            rs = st.executeQuery(sql);
            while (rs.next()){
                System.out.println("\t" + rs.getString("DNI") + ",\t" + rs.getString("Nombre") + ",\t" + rs.getString("Edad") + ",\n");
            }
            
            // Selecciona datos de la tabla "Coches".
            sql = "SELECT * FROM Coches";
            rs = st.executeQuery(sql);
            while (rs.next()){
                System.out.println("\t" + rs.getString("DNI") + ",\t" + rs.getString("Nombre") + ",\t" + rs.getString("Edad") + ",\n");
            }
            /*
            // Consulta a petición del usuario.
            Scanner user = new Scanner(System.in);
            System.out.print("Por favor, introduzca la inial del cliente a buscar: ");
            String firstLetter = user.nextLine();
            
                // Petición de búsqueda de personas cuyo apellido empiece por la letra indicada.
            sql = "SELECT * FROM CLIENTE WHERE APELLIDOS LIKE '" + firstLetter.toUpperCase() + "%';";
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()){
                System.out.println("\t" + rs.getString("DNI") + ",\t" + rs.getString("APELLIDOS") + ",\t" + rs.getString("CP") + ",\n");
            }*/
      } catch (SQLException sqlex){
            System.getLogger(PruebaAccesoDatos.class.getName()).log(System.Logger.Level.ERROR, (String) null, sqlex);
            System.out.println(sqlex.getMessage());
      }
  }
}