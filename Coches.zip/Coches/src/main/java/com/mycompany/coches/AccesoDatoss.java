/**
 *
 * @author Rodrigo
 */
package com.mycompany.coches;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class AccesoDatos{
    // Método para crear la conexión con la DB dado una direción, url, un usuario y una contraseña.
    private Connection conexion;
    
    // Configuración para MySQL en Docker.
    private static final String URL = "jdbc:mysql://localhost:3306";
    private static final String USER = "root";
    private static final String PASSWORD = "root";
    
    
    // Abre conexión con la base de datos.
    public void abrirConexion() throws SQLException{
        conexion = DriverManager.getConnection(URL, USER, PASSWORD);
        System.out.println("\nConexión abierta con la base de datos DatosCoches.");
    }

}
private static void AccesoDatos() extends DB_Connection{
    try (Connection cn = DriverManager.getConnection(URL, USER, PASSWORD);){
        System.out.println("\n\n\t\tConectado a la base de datos.");
        Statement st = cn.createStatement();

        // Crea una base de datos si no existe.
        String sql = "CREATE DATABASE IF NOT EXISTS COCHES;";
        st.execute(sql);
        System.out.println("\n\n\t\tBase de datos creada.");

        // Seleciona la base de datos creada.
        st.execute("USE COCHES");

        // Crea una nueva tabla.
        sql = "CREATE TABLE IF NOT EXISTS CLIENTE (" +
                  "DNI CHAR(9) NOT NULL," +
                  "APELLIDOS VARCHAR(32) NOT NULL," +
                  "CP CHAR(5)," +
                  "PRIMARY KEY (DNI)" +
            ")";
        st.execute(sql);
        System.out.println("\n\n\t\tTabla creadda.\n\n");

        /*
        // Inserta nuevos datos en la tabla creada.
            // Declara una variable que tendrá la función de contabilizar el número de filas.
        int rowsAffected = 0;

        sql = "INSERT INTO CLIENTE (DNI, APELLIDOS, CP) VALUES" +
                  "('123456789', 'MARTINEZ', '35580')," +
                  "('987654321', 'HERNANDEZ', '38520')," +
                  "('147258369', 'GUTIERREZ', '35500')," +
                  "('963852741', 'GARCÍA', '35580')";
        rowsAffected = st.executeUpdate(sql);
        System.out.println("\tSe han insertado un total de " + rowsAffected + " filas.");
        */
        /*
        // Selecciona datos de la tabla.
        sql = "SELECT * FROM CLIENTE";
        ResultSet rs = st.executeQuery(sql);
        while (rs.next()){
            System.out.println("\t" + rs.getString("DNI") + ",\t" + rs.getString("APELLIDOS") + ",\t" + rs.getString("CP") + ",\n");
        }
        */
        // Consulta a petición del usuario.
        Scanner user = new Scanner(System.in);
        System.out.print("Por favor, introduzca la inial del cliente a buscar: ");
        String firstLetter = user.nextLine();

            // Petición de búsqueda de personas cuyo apellido empiece por la letra indicada.
        sql = "SELECT * FROM CLIENTE WHERE APELLIDOS LIKE '" + firstLetter.toUpperCase() + "%';";
        ResultSet rs = st.executeQuery(sql);
        while (rs.next()){
            System.out.println("\t" + rs.getString("DNI") + ",\t" + rs.getString("APELLIDOS") + ",\t" + rs.getString("CP") + ",\n");
        }
    } catch (SQLException sqlex){
        System.getLogger(com.mycompany.coches.AccesoDatos.class.getName()).log(System.Logger.Level.ERROR, (String) null, sqlex);
        System.out.println(sqlex.getMessage());
    }
    return null;
}