/**
 *
 * @author Rodrigo
 */
package com.mycompany.coches;


// Importa de la biblioteca/librería el paquete "Connection".
import java.sql.Connection;
// Importa de la biblioteca/librería el paquete "DriverManager".
import java.sql.DriverManager;
// Importa de la biblioteca/librería el paquete "PreparedStatement".
import java.sql.PreparedStatement;
// Importa de la biblioteca/librería el paquete "ResultSet".
import java.sql.ResultSet;
// Importa de la biblioteca/librería el paquete "SQLException".
import java.sql.SQLException;
// Importa de la biblioteca/librería el paquete "Statement".
import java.sql.Statement;

// Crea la clase principal del programa.
public class AccesoDatos{
    // Método para crear la conexión con la DB dado una direción, url, un usuario y una contraseña.
    private Connection conexion;
    
    // Configuración para MySQL en Docker.
    private static final String URL_ROOT = "jdbc:mysql://localhost:3306/";
    private static final String DB_NAME = "DatosCoches";
    private static final String USER = "root";
    private static final String PASSWORD = "root";
    private static final String URL = "jdbc:mysql://localhost:3306/" + DB_NAME;
    
    // Crea el método "crearBaseDeDatos".
    public void crearBaseDeDatos(){
        try (Connection cn = DriverManager.getConnection(URL_ROOT, DB_NAME, USER, PASSWORD); Statement st = cn.createStatement()){
            System.out.println("\n\n\t\tConectado al servidor MySQL.");
            
            // Crea una base de datos si no existe.
            String sql = "CREATE DATABASE IF NOT EXISTS " + DB_NAME + ";";
            st.execute(sql);
            System.out.println("\n\n\t\tBase de datos, '" + DB_NAME + "', ha sido creada exitosamente.");
            
            // Conexión a la base de datos creada.
            conexion = DriverManager.getConnection(URL_ROOT + DB_NAME, USER, PASSWORD);
            System.out.println("\n\n\tConexión con la/a la base de datos abierta " + DB_NAME + ".\n");
            
        } catch (SQLException sqlex){
            System.getLogger(AccesoDatos.class.getName()).log(System.Logger.Level.ERROR, (String) null, sqlex);
            System.out.println("\n\n\tError al crear la base de datos: " +sqlex.getMessage());
        }
    }
    
    // Crea el método "crearBaseDeDatos".
    public void abrirConexion(){
        try (Connection cn = DriverManager.getConnection(URL_ROOT, USER, PASSWORD, DB_NAME); Statement st = cn.createStatement()){
            System.out.println("\n\n\t\tConectado al servidor MySQL.");
            
            // Crea una base de datos si no existe.
            String sql = "CREATE DATABASE IF NOT EXISTS " + DB_NAME + ";";
            st.execute(sql);
            System.out.println("\n\n\t\tBase de datos, '" + DB_NAME + "', ha sido creada exitosamente.");
            
            // Conexión a la base de datos creada.
            conexion = DriverManager.getConnection(URL_ROOT + DB_NAME, USER, PASSWORD);
            System.out.println("\n\n\tConexión con la/a la base de datos abierta " + DB_NAME + ".\n");
            
        } catch (SQLException sqlex){
            System.getLogger(AccesoDatos.class.getName()).log(System.Logger.Level.ERROR, (String) null, sqlex);
            System.out.println("\n\n\tError al crear la base de datos: " +sqlex.getMessage());
        }
    }
    
    // Crea un método para crear las tablas, en caso de que no existan.
    private void crearTablasSiNoExisten() throws SQLException{
        try (Statement st = conexion.createStatement()){
            String sql;
            
            // Crea la tabla "Propietarios".
            sql = "CREATE TABLE IF NOT EXISTS Propietarios (" +
                    "DNI VARCHAR(10) PRIMARY KEY," +
                    "Nombre VARCHAR(40)," +
                    "Edad INTEGER" +
               ")";
            st.execute(sql);
            System.out.println("\n\n\t\tTabla 'Propietarios' ha sido creadda exitosamente.");

            sql = "CREATE TABLE IF NOT EXISTS Coches (" +
                      "Matricula VARCHAR(10) PRIMARY KEY," +
                      "Marca VARCHAR(20)," +
                      "Precio INTEGER," +
                      "DNI VARCHAR(10)," +
                      "FOREIGN KEY (DNI) REFERENCES Propietarios(DNI)" +
                ")";
            st.execute(sql);
            System.out.println("\n\t\tTabla 'Coches' ha sido creadda exitosamente.\n\n");
            
            System.out.println("\n\n\t\tTabla verificadas y creadas correctamente.\n\n");
        }
    }            
    
    // Crea un método para insertar los datos iniciales, en caso de que las tablas esten vacías.
    private void insertarDatosIniciales() throws SQLException{
        try (Statement st = conexion.createStatement()){
            ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM Propietarios");
            rs.next();
            int count = rs.getInt(1);
            
            if (count == 0){
                System.out.println("\n\n\t\tInsertando datos iniciales...");
                
                st.executeUpdate("INSERT INTO Propietarios VALUES ('1A','Pepe',30), ('1B','Ana',40), ('1C','Maria',50)");
                st.executeUpdate("INSERT INTO Coches VALUES ('MA-1111','Opel',1000,'1A'), ('MA-2222','Renault',2000,'1A'), ('BA-3333','Seat',3000,'1B')");
                
                System.out.println("\n\n\t\tDatos iniciales insertados correctamente.");
            } else{
                System.out.println("\n\n\t\tLa base de datos ya contiene datos, no se han insertado los datos iniciales.");
            }
        }
    }
    
    // Crea un método para cerrar la conexión.
    private void cerrarConexion() throws SQLException{
        if (conexion != null && !conexion.isClosed()){
            conexion.close();
            
            System.out.println("\n\n\t\tConexión cerrada.");
        }
    }
    
    // Crea un método para mostrar los coches ordenados por precio (descendente).
    private void mostrarDatosCoches() throws SQLException{
        String sql = "SELECT * FROM Coches ORDER BY Precio DESC";
        
        try (Statement st = conexion.createStatement();
             ResultSet rs = st.executeQuery(sql)){

            System.out.println("\n\n\t\tLista de coches (de mayor a menor precio):");
            
            while (rs.next()){
                System.out.println("\n\n\t\tMatricula: " + rs.getString("Matricula") + "\n\t\t\tMarca: " + rs.getString("Marca") + "\n\t\t\tPrecio: " + rs.getInt("Precio") + "\n\t\t\tPropietario: " + rs.getString("DNI"));
            }
            System.out.println();
        }
    }
    
    // Crea un método para modificar el precio de un coche según su matrícula.
    private void modificarCoche(String matricula, int precio)throws SQLException{
        String sql = "UPDATE Coches SET Precio = ? WHERE Matricula = ?"; /* Los "?" son parámetros. */
        
        try (PreparedStatement ps = conexion.prepareStatement(sql)){
            ps.setInt(1, precio); /*Parámetro 1. */
            ps.setString(2, matricula); /*Parámetro 2. */
            
            int filas = ps.executeUpdate();
            
            System.out.println("\n\n\t\tSe han modificado/actualizado: " + filas + " fila(s) del Coche.");
        }
    }
    
    // Crea un método para borra un coche por matrícula.
    public void borrarCoche(String matricula) throws SQLException{
        String sql = "DELETE FROM Coches WHERE Matricula LIKE ?";
        
        try (PreparedStatement ps = conexion.prepareStatement(sql)){
            ps.setString(1, matricula + "%"); /* El "%" es un parámetro qque funciona como dentro de la cláusula "LIKE" como comodín, y significa “cualquier secuencia de caracteres”. */
            int filas = ps.executeUpdate();
            
            System.out.println("\n\n\t\tEl registro/s del Coche ha/n sido eliminado(s): " + filas + " fila(s).");
        }
    }
    
    // Crea un método para insertar un coche, pero sólo si el propietario existe.
    public void insertarCocheinsertarCoche(String matricula, String marca, int precio, String dni) throws SQLException{
        if (!existePropietario(dni)){
            System.out.println("\n\n\t\tNo se puede insertar coche: el propietario con DNI (" + dni + ") no existe.");
            return;
        }
        
        String sql = "INSERT INTO Coches (Matricula, Marca, Precio, DNI) VALUES (?, ?, ?, ?)";
        
        try (PreparedStatement ps = conexion.prepareStatement(sql)){
            ps.setString(1, matricula);
            ps.setString(2, marca);
            ps.setInt(3, precio);
            ps.setString(4, dni);
            ps.executeUpdate();
            System.out.println("\n\n\t\tCoche y sus datos han sido insertados correctamente.");
        }
    }
    
    // Crea un método para insertar un propietario.
    public void insertarPropietario(String dni, String nombre, int edad) throws SQLException{
        String sql = "INSERT INTO Propietarios (DNI, Nombre, Edad) VALUES (?, ?, ?)";
        
        try (PreparedStatement ps = conexion.prepareStatement(sql)){
            ps.setString(1, dni);
            ps.setString(2, nombre);
            ps.setInt(3, edad);
            ps.executeUpdate();
            System.out.println("\n\n\t\tPropietario y sus datos han sido insertados correctamente.");
        }
    }
    
    // Crea un método para mostrar los datos de un propietario y los coches que tiene.
    public void mostrarPropietarioYCoches(String dni) throws SQLException{
        String sqlProp = "SELECT * FROM Propietarios WHERE DNI = ?";
        String sqlCoches = "SELECT * FROM Coches WHERE DNI = ?";

        try (PreparedStatement ps1 = conexion.prepareStatement(sqlProp);
             PreparedStatement ps2 = conexion.prepareStatement(sqlCoches)){

            ps1.setString(1, dni);
            ResultSet rs1 = ps1.executeQuery();

            if (rs1.next()){
                System.out.println("\n\n\t\tPropietario:\n\t\t\tDNI: " + rs1.getString("DNI") + "\n\t\t\tNombre: " + rs1.getString("Nombre") + "\n\t\t\tEdad: " + rs1.getInt("Edad"));

                System.out.println("\n\n\t\tCoches del propietario:");
                ps2.setString(1, dni);
                ResultSet rs2 = ps2.executeQuery();
                boolean tieneCoches = false;
                
                while (rs2.next()){
                    tieneCoches = true;
                    System.out.println(" - " + rs2.getString("Matricula") + " (" + rs2.getString("Marca") + "), Precio: " + rs2.getInt("Precio"));
                }
                
                if (!tieneCoches){
                    System.out.println("\n\n\t\tEste propietario no tiene coches.");
                }
            } else{
                System.out.println("\n\n\t\tNo existe propietario con dicho DNI (" + dni + ").");
            }
        }
    }
    
    // Crea un método para borrar un propietario y sus coches
    public void borrarPropietario(String dni) throws SQLException{
        // Primero borrar coches del propietario
        String borrarCoches = "DELETE FROM Coches WHERE DNI = ?";
        
        try (PreparedStatement psCoches = conexion.prepareStatement(borrarCoches)){
            psCoches.setString(1, dni);
            psCoches.executeUpdate();
        }

        // Declara una variable para borrar el propietario.
        String borrarProp = "DELETE FROM Propietarios WHERE DNI = ?";
        
        try (PreparedStatement ps = conexion.prepareStatement(borrarProp)){
            ps.setString(1, dni);
            int filas = ps.executeUpdate();
            
            System.out.println("🧹 Propietario y coches asociados eliminados (" + filas + " propietario borrado).");
        }
    }

    // Crea un método auxiliar: comprobar si un propietario existe.
    private boolean existePropietario(String dni) throws SQLException{
        String sql = "SELECT * FROM Propietarios WHERE DNI = ?";
        
        try (PreparedStatement ps = conexion.prepareStatement(sql)){
            ps.setString(1, dni);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        }
    }
}